package com.capgemini;

import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.controller.ShipwreckStub;
import com.capgemini.modell.Shipwreck;

@RequestMapping("api/v1")
@RestController
public class ShipWreckController {

	@RequestMapping(method=RequestMethod.GET,value="shipwrecks")
	public List<Shipwreck> list(){
		
		return ShipwreckStub.list();
	}
	
}
